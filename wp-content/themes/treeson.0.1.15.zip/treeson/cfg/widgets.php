<?php
get_template_part( 'cfg/widgets/mythemes.blog_details.class' );
get_template_part( 'cfg/widgets/mythemes.post_meta.class' );
get_template_part( 'cfg/widgets/mythemes.post_categories.class' );
get_template_part( 'cfg/widgets/mythemes.post_tags.class' );
?>