<!--[if IE]>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/media/_frontend/css/ie.css" />
<![endif]-->

<!--[if lt IE 9]>
  <script src="<?php echo get_template_directory_uri(); ?>/media/_frontend/js/html5shiv.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/media/_frontend/js/respond.min.js"></script>
<![endif]-->