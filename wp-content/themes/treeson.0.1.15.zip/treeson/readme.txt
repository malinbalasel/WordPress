
    Treeson


    Thank you for choosing myThem.es and use one of our WordPress Themes
    your choice is greatly appreciated!


    myThem.es Marketplace provides WordPress themes with
    the best quality and the smallest prices.
    

    Treeson, Copyright 2015 myThem.es

    Treeson is distributed under the terms of the
    GNU GENERAL PUBLIC LICENSE


   *****************************************************************************


                     ________________
                    |_____    _______|
     ___ ___ ___   __ __  |  |  __       ____   ___ ___ ___       ____   ____ 
    |   |   |   | |_ |  | |  | |  |___  |  __| |   |   |   |     |  __| |  __|
    |   |   |   |  | |  | |  | |  __  | |  __| |   |   |   |  _  |  __| |__  |
    |___|___|___|   |  |  |__| |_ ||_ | |____| |___|___|___| |_| |____| |____|   
                    |_|



   *****************************************************************************



    - Theme URI         : http://mythem.es/item/treeson-free-wordpress-theme/
    - Support URI       : http://mythem.es/forums/forum/themes/treeson/treeson-free/

    - Author            : myThem.es
    - Author URI        : http://mythem.es

    - Demo URI          : http://test.mythem.es/treeson-wordpress/


    
   *****************************************************************************



    - More about            : http://www.google.com/fonts#AboutPlace:about
    - Used Fonts            : Roboto, Open Sans

    - Used Icons Fonts	    : Fontello
    - Fontello URI 	        : http://fontello.com/



   *****************************************************************************


    Header image licensed under Creative Commons Zero
    https://unsplash.com/jamesforbes
	
    Bootstrap 3.3.1, Copyright (c) 2010-14, Twitter, Inc.
    Bootstrap is under the terms of MIT License.
    http://getbootstrap.com


    HTML5 Shiv v3.7.0, Copyright (c) @afarkas @jdalton @jon_neal @rem
    HTML5 Shiv v3.7.0 is under the terms of MIT License.


    Respond.js v1.4.2, Copyright (c) 2013 Scott Jehl
    Respond.js v1.4.2 is under the terms of MIT License.
    http://scottjehl.com


    prettyPhoto v3.1.5, Copyright (c) Stephane Caron
    prettyPhoto is under the terms of GPLV2 License.
    You are free to use prettyPhoto in commercial projects as long as the
    copyright header is left intact.

    http://www.no-margin-for-errors.com
    

   *****************************************************************************


    HOW TO USE


    1. WELCOME MESSAGE

    Thank you for choosing myThem.es and use one of our WordPress Themes your
    choice is greatly appreciated!

    If you have any questions ask!

    Before ask, please read all topics from our forums, marked as AUTHOR SUGGEST:
    http://mythem.es/forums/forum/themes/treeson/treeson-free/  

    And please help us to increase the theme quality ( report bugs ).

    Also please help us to increase the theme rank!


    2. THEME OPTIONS

    This theme comes with a set of options what allow you to customize content,
    header, layouts, social items and others.

    You can see theme options if you go to Admin Dashboard
    Appearance > Theme Options

    Here you can see:

    BRANDING

    - upload custom favicon
    - upload custom logo

    COLORS

    - first color
    - second color
    - third color

    HEADER

    These option allow you customize HEADER image and components
    ( before menu on front page, single post, single page, blog and others templates ).

    - Enabale / Disable Header on different templates
    - Header height ( in pixels )
    - Mask Color and opacity - this is a special effect. That applies like a layer,
      of a certain semi-transparent color, over the image in the header. This effect
      allows us to make the text more readable.

    HEADER CONTENT 

    - Title
    - Description
    - Description Color

    HEADER BUTTONS

    - First Button
    - Second Button

    DEFAULT LAYOUTS
    FRONT PAGE LAYOUT
    DEFAULT PAGE LAYOUT
    DEFAULT POST LAYOUT
    SPECIAL PAGE LAYOUT ( ONLY FOR ONE PAGE YOU CAN ADD A SPECIAL LAYOUT )

    These options allow customize web site layouts ( with sidebar or without ).

    Exists 5 sidebars that can be used to customize layout:

    - Main Sidebar
    - Front Page Sidebar
    - Default Page Sidebar
    - Default Post Sidebar
    - Special Page Sidebar

    BREADCRUMBS 

    - enable / disable
    - "Home" label
    - "Home" link description
    - Space ( in pixels)

    ADDITIONAL

    - Title for Blog Page
    - enable / disable - Top meta
    - enable / disable - Bottom meta
    - enable / disable - HTML Suggestions after comments form

    SOCIAL

    - these options allow add your social links in footer side ( 26 social networks ).

    OTHERS

    - Custom css: allow you add custom css to customize your web site.
    - Copyright

    3. UPGRADE TO PREMIUM

    I want to inform you that we have the premium version for this theme. 
    You can buy the premium version only $ 40.

    details: http://mythem.es/item/treeson-premium-multipurpose-wordpress-theme/
    demo: http://test.mythem.es/treeson-premium-wordpress/